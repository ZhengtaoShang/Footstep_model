from pathlib import Path
import h5py
import numpy as np
import torch
from torch.utils.data import Dataset


class FNCNet(Dataset):
    def __init__(self, data_root, mode="train"):
        if mode not in ("train", "valid", "test"):
            raise ValueError(mode)
        self.mode = mode
        self.path = Path(data_root) / f"{mode}.h5"
        with h5py.File(self.path, "r") as f:
            self.data = np.asarray(f["data"][:], dtype=np.float32)
            raw_labels = f["valid_labels"][:].reshape(-1)
            self.on_labels = f["t_on_labels"][:]
            self.off_labels = f["t_off_labels"][:]
            self.names_labels = [n.decode() if isinstance(n, bytes) else str(n) for n in f["names"][:]]

        self.valid_labels = raw_labels.astype(np.int64)
        self.tensor = torch.from_numpy(self.data)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        return self.tensor[index], self.names_labels[index], int(self.valid_labels[index])


def get_data_and_label(args, mode):
    return FNCNet(args.data_root, mode)
