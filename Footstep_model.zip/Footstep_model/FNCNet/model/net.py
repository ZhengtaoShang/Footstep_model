import torch
from torch import nn

class BasicBlock1D(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=2):
        super().__init__()
        self.conv1 = nn.Conv1d(in_channels, out_channels, kernel_size,
                               padding=kernel_size // 2, stride=stride)
        self.bn1 = nn.BatchNorm1d(out_channels)
        self.gelu = nn.GELU()
        self.conv2 = nn.Conv1d(out_channels, out_channels, kernel_size,
                               padding=kernel_size - 1, dilation=2, groups=2)
        self.bn2 = nn.BatchNorm1d(out_channels)
        self.downsample = nn.Conv1d(in_channels, out_channels, 1, stride=stride)

    def forward(self, x):
        y = self.gelu(self.bn1(self.conv1(x)))
        y = self.bn2(self.conv2(y))
        return self.gelu(y + self.downsample(x))


class SEBlock(nn.Module):
    def __init__(self, channels=128, reduction=16):
        super().__init__()
        self.fc = nn.Sequential(
            nn.AdaptiveAvgPool1d(1),
            nn.Conv1d(channels, channels // reduction, 1), nn.GELU(),
            nn.Conv1d(channels // reduction, channels, 1), nn.Sigmoid(),
        )

    def forward(self, x):
        return x * self.fc(x)

class ResBranch(nn.Module):
    def __init__(self, kernels, strides, drop_rate):
        super().__init__()
        self.layer1 = BasicBlock1D(1, 32, kernels[0], strides[0])
        self.layer2 = BasicBlock1D(32, 64, kernels[1], strides[1])
        self.layer3 = BasicBlock1D(64, 128, kernels[2], strides[2])
        self.se = SEBlock()
        self.dropout = nn.Dropout(drop_rate)
        self.pool = nn.AdaptiveAvgPool1d(1)

    def forward(self, x):
        x = self.layer3(self.layer2(self.layer1(x)))
        x = self.pool(self.dropout(self.se(x)))
        x = x.view(x.size(0), -1)
        return x


class SingleBranchNet(nn.Module):
    def __init__(self, kernels=(9, 7, 5), strides=(2, 2, 2),drop_rate=0.1):
        super().__init__()
        if len(kernels) != 3 or any(k < 1 or k % 2 == 0 for k in kernels):
            raise ValueError("Three positive odd kernel sizes are required")
        if len(strides) != 3 or any(s not in (1, 2) for s in strides):
            raise ValueError("Three strides in {1, 2} are required")
        self.branch = ResBranch(kernels, strides, drop_rate)
        self.fc1 = nn.Linear(128, 64)
        self.fc2 = nn.Linear(64, 16)
        self.fc3 = nn.Linear(16, 6)

    def forward(self, x):
        x = self.fc1(self.branch(x))
        x = self.fc2(x)
        return self.fc3(x)


CANDIDATES = {
    "k1195": dict(kernels=(11, 9, 5)),
}

def get_model(candidate):
    return SingleBranchNet(**CANDIDATES[candidate])


def get_loss(class_weights=None):
    return nn.CrossEntropyLoss(weight=class_weights)
