import torch
import torch.nn as nn
import torch.nn.functional as F


class ResidualBlock1D(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(ResidualBlock1D, self).__init__()
        self.conv1 = nn.Conv1d(in_channels, out_channels, kernel_size=3, padding=1, stride=2)
        self.bn1 = nn.BatchNorm1d(out_channels)
        self.gelu = nn.GELU()
        self.conv2 = nn.Conv1d(out_channels, out_channels, kernel_size=3, stride=1, padding=2, dilation=2, groups=2)
        self.bn2 = nn.BatchNorm1d(out_channels)
        self.downsample = nn.Conv1d(in_channels, out_channels, kernel_size=1, stride=2)
        
    def forward(self, x):

        out = self.gelu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))

        identity = self.downsample(x)
        out += identity
        return self.gelu(out)


class CrossAttentionBlock(nn.Module):

    def __init__(self, d_model: int, nhead: int, dim_feedforward: int = 4*256, dropout: float = 0.1):
        super().__init__()
        self.mha = nn.MultiheadAttention(d_model, nhead, dropout=dropout, batch_first=False)  # 输入(L,B,D)
        self.ln1 = nn.LayerNorm(d_model)
        self.ffn = nn.Sequential(
            nn.Linear(d_model, dim_feedforward),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim_feedforward, d_model)
        )
        self.ln2 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, Q: torch.Tensor, K: torch.Tensor, V: torch.Tensor) -> torch.Tensor:
        attn_out, _ = self.mha(Q, K, V, need_weights=False)
        x = self.ln1(Q + self.dropout(attn_out))
        ffn_out = self.ffn(x)
        x = self.ln2(x + self.dropout(ffn_out))
        return x


class WaveformBackbone(nn.Module):

    def __init__(self, d_model: int = 128):
        super().__init__()
        
        self.layer1 = ResidualBlock1D(3, 32)
        self.layer2 = ResidualBlock1D(32, 64)
        self.layer3 = ResidualBlock1D(64, d_model)

    def forward(self, x: torch.Tensor) -> torch.Tensor:


        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x) 
        x = x.transpose(1, 2) 
        x = x.transpose(0, 1) 
        return x



class CovarianceBranch(nn.Module):

    def __init__(self, d_model: int = 128):
        super().__init__()
        self.proj = nn.Sequential(
            nn.Conv1d(3, 64, kernel_size=1, bias=False),
            nn.BatchNorm1d(64),
            nn.GELU(),
            nn.Conv1d(64, d_model, kernel_size=1, bias=False),
            nn.BatchNorm1d(d_model),
            nn.GELU()
        )

    def forward(self, c: torch.Tensor) -> torch.Tensor:

        x = self.proj(c)           
        x = x.transpose(1, 2)   
        x = x.transpose(0, 1)   
        return x


class BazCrossAttnModel(nn.Module):

    def __init__(self, d_model: int = 128, nhead: int = 8, ffn_dim: int = 1024, dropout: float = 0.1):
        super().__init__()
        self.wave = WaveformBackbone(d_model=d_model)  # K,V
        self.cov  = CovarianceBranch(d_model=d_model)  # Q
        self.xattn = CrossAttentionBlock(d_model, nhead, dim_feedforward=ffn_dim, dropout=dropout)

        self.head = nn.Sequential(
            nn.LayerNorm(d_model),
            nn.Linear(d_model, d_model // 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_model // 2, 2)  # cos, sin
        )

    def forward(self, wave: torch.Tensor, cov: torch.Tensor) -> torch.Tensor:

        KV = self.wave(wave)   
        Q  = self.cov(cov) 

        fused = self.xattn(Q, KV, KV)

        feat = fused[0]             
        out = self.head(feat)
        out = F.normalize(out, p=2, dim=-1)
        return out

def directional_loss(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    pred = F.normalize(pred, p=2, dim=-1)
    target = F.normalize(target, p=2, dim=-1)
    loss = 1.0 - (pred * target).sum(dim=-1)
    return loss.mean()

def get_model():
    return BazCrossAttnModel()

