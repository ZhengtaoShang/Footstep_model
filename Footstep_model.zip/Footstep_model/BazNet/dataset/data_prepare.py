import h5py
import numpy as np
import torch.utils.data as data
from pathlib import Path


class Baz_net(data.Dataset):

    def __init__(self, data_root, mode:str='train', samples_angle:int=360, channels:int=3):
        
        super().__init__()
        self.data_root = Path(data_root)
        self.samples_angle = samples_angle
        self.channels=channels

        mode_h5 =  h5py.File(self.data_root.joinpath(f'{mode}.h5'),'r')
        self.data = mode_h5['data']
        self.on_labels = mode_h5['t_on_labels']
        self.off_labels = mode_h5['t_off_labels']
        self.angle_labels = mode_h5['theta_labels']
        self.names_labels = mode_h5['names']

    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, index):
        return self._generate_item(index)


    def _generate_item(self, index):

        data_1 = self.data[index]

        cov_p = np.cov(data_1.T, rowvar=False)   
        try:
            eVa, eVe = np.linalg.eig(cov_p)
            eVa /= np.max(eVa)
        except Exception:
            eVa = [None, None, None]            
            pass
        cov_p /= np.max(abs(cov_p)) 
        eVa /= np.max(eVa)

        data_2 = np.zeros([3,7])
        data_2[:,:3] = cov_p
        data_2[0,3] = eVa[0]
        data_2[1,3] = eVa[1]
        data_2[2,3] = eVa[2]
        data_2[:,4:] = eVe


        angle = self.angle_labels[index]
        # print(angle)
        t_start = self.names_labels[index].decode()


        angle_label = self._generate_label(angle)
        return data_1, data_2, angle_label, t_start

    def _generate_label(self, angle):

        angle_in_radians = np.radians(angle)

        angle_label = np.zeros((2))
        angle_label[0] = np.cos(angle_in_radians)
        angle_label[1] = np.sin(angle_in_radians)

        return angle_label


def get_data_and_label(args, mode):
  
    dataset = Baz_net(args.data_root, mode)

    return dataset

